import 'package:flutter/material.dart';
import 'package:flutter_travel/model/place.dart';

import 'widget/deskripsi.dart';
import 'widget/atribut.dart';

import 'widget/my_header.dart';
import 'widget/detail_nama.dart';

class DetailScreen extends StatelessWidget {
  final Place place;
  DetailScreen({@required this.place});
  @override
  Widget build(BuildContext context) {
    // return Scaffold(
    //   body: Column(
    //     crossAxisAlignment: CrossAxisAlignment.start,
    //     children: [
    //       MyHeader(),
    //       PlaceAndName(),
    //       SizedBox(
    //         height: 36,
    //       ),
    //       About(),
    //
    //     ],
    //   ),
    // );
    return LayoutBuilder(
        builder: (BuildContext context,BoxConstraints constraints){
          if(constraints.maxWidth > 800){
            return DetailWebPage(place:place);
          }
          else {
            return DetailMobilePage(place:place);
          }
        });

  }
}

class DetailWebPage extends StatefulWidget {
  final Place place;
  const DetailWebPage({@required this.place});

  @override
  _DetailWebPageState createState()=>_DetailWebPageState();


}

class _DetailWebPageState extends State<DetailWebPage> {
  final _scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}

class DetailMobilePage extends StatelessWidget {
  final Place place;
  const DetailMobilePage({this.place});
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
   return Scaffold(
     body: SingleChildScrollView(
       child: Column(
         crossAxisAlignment: CrossAxisAlignment.stretch,
         children: [
           MyHeader(),
           DetailNama(),
           SizedBox(
             height: 36,
           ),
           Deskripsi(),
           Atribut()
         ],

       ),
     ),
   );
  }


}

